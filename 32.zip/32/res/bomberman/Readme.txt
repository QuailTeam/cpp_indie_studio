Here it is the opertunity for all you 
out there to frag your hearts out in
Quake 2 as a Bomberman from the sucessful
Interplay range of games.

Contents: [Contains small pieces - not suitable for children
	   under 36 months of age]

1 tris.md2
1 weapon.md2

3 skins:
	Bomber: A standard Bomberman for your enjoyment
	QuakeII: Includes a 'How am I fraggin' sign and various other
	logos.
	Mexican: Ola gringos, this bomber is from old mexico!

1 weapon.pcx
1 readme: Your reading it

This model isn't washable over temperatures of 40^c even in a slow wash

Use this model to your hearts content but remember who made it:

CITRUS FROG

[idea thanks to the people at Interplay]

someone@becs-ltd.demon.co.uk

I'm not responsible for your machine charshing and burning or sufering
from my model or the .zip it's held in. It's your fault no mine!
